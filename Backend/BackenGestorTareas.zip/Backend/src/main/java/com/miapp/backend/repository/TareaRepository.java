package com.miapp.backend.repository;

import com.miapp.backend.model.Tarea;
import com.miapp.backend.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TareaRepository extends JpaRepository<Tarea, Long> {
    List<Tarea> findByUsuario(Usuario usuario);
}