package com.miapp.backend.repository;

import com.miapp.backend.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {
    Usuario findByUsuarioAndContrasenha(String usuario, String contrasenha);
    
}